const express = require('express');
const bodyParser = require('body-parser');
const sharp = require('sharp');
const AWS = require("aws-sdk");

const app = express();
const s3 = new AWS.S3()
// *******************************************************************************
// MIDDLEWARE
// *******************************************************************************

app.use(bodyParser.json());


// *******************************************************************************
// ROUTES
// *******************************************************************************

// Upload endpoint

app.post('/upload', async (req, res) => {
  try {
    // if (!req.body.image) {
    //   return res.status(400).json({ error: 'No image uploaded' });
    // }

    const {email , image} = req.body
    // Extract metadata from the uploaded image
    const metadata = await sharp(Buffer.from(image, 'base64')).metadata();

    // Upload image to S3
    // const s3Client = new S3Client({
    //   region: 'us-east-1', // Specify your desired AWS region
    //   credentials: {
    //     accessKeyId: process.env.AWS_ACCESS_KEY_ID, // Use environment variables instead of hardcoding
    //     secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    //     sessionToken: process.env.AWS_SESSION_TOKEN // If you're using temporary credentials
    //   }
    // });
    const bucketName = 'tas3'; // Replace with your S3 bucket name
    const key = bucketName + email.split('@')[0] // Generate a unique key for the image (assuming it's always a JPEG)
    const uploadParams = {
      Bucket: bucketName,
      Key: key,
      Body: Buffer.from(image, 'base64'),
    };

    await s3Client.upload(uploadParams); // Upload the image to S3

    // Call service to process image and send metadata to email
    // const email = req.body.email;
    // if (!email) {
      // return res.status(400).json({ error: 'Email is required' });
    // }
    // const result = await sendMail(email, key, metadata);/

    res.json({ message: 'Image uploaded and metadata sent successfully!' });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ error: 'Failed to upload image and send metadata' });
  }
});


// *******************************************************************************
// CODE
// *******************************************************************************

// Function to send email
// async function sendMail(email, filename, metadata) {
//   const transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//       user: 'kapoordhruv22@gmail.com',
//       pass: 'hlgi ugyf nnmx wonz'
//     }
//   });

//   // Create email body with metadata
//   const mailOptions = {
//     from: 'kapoordhruv22@gmail.com',
//     to: email,
//     subject: 'Image Metadata',
//     text: `Here is the metadata for your uploaded image ${filename}:\n\n` +
//           `Width: ${metadata.width}px\n` +
//           `Height: ${metadata.height}px\n` +
//           `Format: ${metadata.format}\n` +
//           `Size: ${metadata.size} bytes\n` +
//           `Type: ${metadata.type}`
//   };

//   await transporter.sendMail(mailOptions);
// }

// *******************************************************************************
// SERVER
// *******************************************************************************

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
